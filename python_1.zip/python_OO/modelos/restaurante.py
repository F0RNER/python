class Restaurante: #Restaurante agora é uma classe.
    restaurantes = []
    def __init__(self, nome, categoria):#Isso é um metodo construtor, ou seja, dsempre que criarmos a instancia de um objetos, esse metodo é chamado e ele espera uma info. O self é para ele identificar o objeto que está sendo usando como parametro.
        self.nome = nome
        self.categoria = categoria
        self.status = False
        Restaurante.restaurantes.append(self)
    def __str__(self):#mostra o objeto em formato de texto.
        return f'{self.nome} | {self.categoria} | {self.status}'
    
    def listar_restaurantes():#Criação de um metodo
        for restaurante in Restaurante.restaurantes:
            print (f'{restaurante.nome} | {restaurante.categoria} | {restaurante.status}')
        

restaurante_praca = Restaurante('Praça', 'Gourmet') #restaurante_praca virou o objeto da classe Restaurante
restaurante_pizza = Restaurante('Pizza Express', 'Italiano')


#print (dir(restaurante_praca)) #O dir mostra os atributos do objeto, mas ele vai mostrar todos os atributos, os que ele herda do python também. Já o vars mostra somente o dicionário desses metodos, ou seja, o que criamos.
#print (vars(restaurante_praca))#O vars mostra os valores dos atributos. Sem o vars, ele mostra o objeto salvo na memória.

Restaurante.listar_restaurantes()
