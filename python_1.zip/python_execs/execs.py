# # Imprima a frase: Python na Escola de Programação da Alura.
# print('Python na escola de programação da Alura\n\n')

# #2 - Imprima a frase: Meu nome é {nome} e tenho 
# #{idade} anos em que nome e idade precisam ser valores armazenados em variáveis.
# nome = 'mateus'
# idade = 25
# print(f"Meu nome é {nome} e tenho {idade} anos\n\n")

# #Imprima a palavra: ‘ALURA’ de modo que cada letra fique em uma linha, como mostrado 
# #a seguir:


# print("""\033[31mA\033[0m
# L
# U
# R
# \033[31mA\033[0m\n\n""")


# #4 - Imprima a frase: O valor arredondado de pi é: {pi_arredondado} em que o valor de pi precisa ser armazenado em uma variável e arredondado para apenas duas casas decimais. 
# #Para facilitar, utilize pi = 3.14159:
# pi = 3.14159
# pi_arredondado = round(pi,2)
# print(f'O valor de pi é: {pi_arredondado} ')

# #1 - Solicite ao usuário que insira um número e, em seguida, use uma estrutura if else para determinar 
# #se o número é par ou ímpar.

# numero_teste = int(input('Digite um número: '))
# if (numero_teste%2 == 0):
#     print('Seu número é par.')
# else:
#     print('Número impar')

# #2 - Pergunte ao usuário sua idade e, com base nisso, use uma estrutura if elif else para classificar 
# #a idade em categorias de acordo com as seguintes condições:

# idade = int(input('Digite sua idade: '))

# if(idade <= 12):
#     print ('Você é uma criança')
# elif(idade > 12 and idade < 18):
#     print('Você é um adolescente')
# else:
#     print('Você é adulto')

# #3 - Solicite um nome de usuário e uma senha e use uma estrutura if else para verificar se o nome
# #de usuário e a senha fornecidos correspondem aos valores esperados determinados por você.    

# usuario_correto = 'admin'
# senha_correta = 'abc123'

# usuario = input ('Digite o usuário: ')
# senha = input ('Digite a senha: ')

# if (usuario == usuario_correto and senha == senha_correta):
#     print('Login ok')
# else:
#     print('Credenciais incorretas.\n\n\n')


# #4 - Solicite ao usuário as coordenadas (x, y) de um ponto qualquer e utilize uma estrutura if elif else para determinar em qual 
# #quadrante do plano cartesiano o ponto se encontra de acordo com as seguintes condições:
# # Primeiro Quadrante: os valores de x e y devem ser maiores que zero;
# # Segundo Quadrante: o valor de x é menor que zero e o valor de y é maior que zero;
# # Terceiro Quadrante: os valores de x e y devem ser menores que zero;
# # Quarto Quadrante: o valor de x é maior que zero e o valor de y é menor que zero;
# # Caso contrário: o ponto está localizado no eixo ou origem.
# coordenada_x = float(input('Digite a coordenada x: '))
# coordenada_y = float(input('Digite a coordenada y: '))

# if (coordenada_x > 0 and coordenada_y > 0):
#     print('Você está no primeiro quadrante')
# elif (coordenada_x < 0 and coordenada_y > 0):
#     print('Voce está no segundo quandrante')
# elif (coordenada_x < 0 and coordenada_y < 0):
#     print ('Você está no terceiro quadrante')
# elif (coordenada_x > 0 and coordenada_y < 0):
#     print('Você está no quarto quadrante')
# else:
#     print('Você está no eixo de origem')

# #1 - Crie uma lista para cada informação a seguir:

# numeros = [1,2,3,4,5,6,7,8,9,10]
# nomes = ['Vitoria', 'Mateus', 'Luciano', 'Tania']
# ano_atual_e_nascimento = [1998,2024]

# #2 - Crie uma lista e utilize um loop
# #for para percorrer todos os elementos da lista.

# lista = [1,2,3,4,5,6]

# for numero in lista:
#     print(f'- {numero}' )


# #3 - Utilize um loop for para 
# #calcular a soma dos números ímpares de 1 a 10.

# soma_impares = 0
# for i in range(1, 11, 2):
#     soma_impares += i
# print(soma_impares)

# # O segundo argumento de da função range é exclusivo, 
# # então range(1, 11) inclui números de 1 a 10) com um passo de 
# # 2 (o terceiro argumento de range). 
# # Isso garante que apenas números ímpares sejam considerados.


# # 5 - Para fazer uma tabuada interativa, você pode seguir o 
# # seguinte código:

# numero_tabuada = int(input("Digite um número para a tabuada: "))
# for i in range(1, 11):
#     resultado = numero_tabuada * i
#     print(f"{numero_tabuada} x {i} = {resultado}")


# # 6 - Uma possível resolução para fazer a soma dos elementos de 
# # uma lista com for e usar try except para validar, está no 
# # código a seguir:

# lista_numeros = [10, 5, 8, 3, 7]
# soma = 0

# try:
#     for numero in lista_numeros:
#         soma += numero
#     print(f"Soma dos elementos: {soma}")
# except Exception as e:
#     print(f"Ocorreu um erro: {e}")


# # Exception é uma classe base para todas as exceções em Python. 
# # Capturar Exception permite lidar com qualquer tipo de exceção 
# # que possa ocorrer no bloco try. O as e é opcional, mas é 
# # frequentemente usado para acessar informações detalhadas sobre 
# # a exceção, como mensagens de erro.


# # 7 - Construa um código que calcule a média dos valores em uma 
# # lista. Utilize um bloco try-except para lidar com a divisão por 
# # zero, caso a lista esteja vazia.

# lista_valores = [15, 20, 25, 30]
# soma_valores = 0

# try:
#     for valor in lista_valores:
#         soma_valores += valor
#     media = soma_valores / len(lista_valores)
#     print(f"Média dos valores: {media}")
# except ZeroDivisionError:
#     print("A lista está vazia, não é possível calcular a média.")
# except Exception as e:
#     print(f"Ocorreu um erro: {e}")

# # ZeroDivisionError é uma exceção específica que ocorre quando há 
# # uma tentativa de divisão por zero. Este bloco except é 
# # destinado a lidar especificamente com esse tipo de erro.

# # 1 - Para criar um dicionário com informações de uma pessoa, você 
# # pode utilizar a seguinte solução:

# pessoa = {'nome': 'Felipe', 'idade': 30, 'cidade': 'São Paulo'}

# # 2 - Para fazer a atualização de um valor, adicionar um item 
# # e remover uma informação, você pode usar o seguinte raciocínio:

# # Atualização de Idade
# pessoa['idade'] = 31

# # Adicionando Profissão
# pessoa['profissao'] = 'Engenheiro'

# # Remoção de Elemento
# del pessoa['cidade']


# # 3 - Uma possível abordagem para criar um dicionário que 
# # apresente os números de 1 a 5 e seus respectivos quadrados 
# # é a seguinte:

# numeros_quadrados = {x: x**2 for x in range(1, 6)}
# print(numeros_quadrados)


# # 4 - Para verificar a existência de uma chave no dicionário, 
# # você pode utilizar a seguinte estrutura:

# pessoa = {'nome': 'Amanda', 'idade': 19, 'cidade': 'São Luís'}
# if 'nome' in pessoa:
#     print("A chave 'nome' existe no dicionário.")
# else:
#     print("A chave 'nome' não existe no dicionário.")

# # 5 - Para contar a frequência de cada palavra em uma frase, você 
# # pode utilizar o seguinte código:

# frase = "Python se tornou uma das linguagens de programação mais populares do mundo nos últimos anos."
# contagem_palavras = {}
# palavras = frase.split()
# for palavra in palavras:
#     contagem_palavras[palavra] = contagem_palavras.get(palavra, 0) + 1
# print(contagem_palavras)

# # Aqui está a mesma classe Musica reescrita de forma mais concisa 
# # utilizando a sintaxe elegante do Python:

# class Musica:
#     nome = ''
#     artista = ''
#     duracao = int


# #Agora podemos definir os objetos:

# musica1 = Musica()
# musica1.nome = 'Bohemian Rhapsody'
# musica1.artista = 'Queen'
# musica1.duracao = 355

# musica2 = Musica()
# musica2.nome = 'Imagine'
# musica2.artista = 'John Lennon'
# musica2.duracao = 183

# musica3 = Musica()
# musica3.nome = 'Shape of You'
# musica3.artista = 'Ed Sheeran'
# musica3.duracao = 234


# # Atribua o valor 'Italiana' ao atributo categoria da instância 
# # restaurante_praca da classe Restaurante.

# class Restaurantes:
#     nome = ''
#     categoria = ''
#     ativo = False

# restaurante_praca = Restaurantes()
# restaurante_praca.nome = 'Restaurante Praça'
# restaurante_praca.categoria = 'Italiana'

# # Acesse o valor do atributo nome da instância 
# # restaurante_praca da classe Restaurante.

# # 2 - Acesse o valor do atributo nome da instância restaurante_praca da classe Restaurante.

# nome_do_restaurante = restaurante_praca.nome

# # 3 - Verifique o valor inicial do atributo ativo para a instância restaurante_praca e exiba uma mensagem informando se o restaurante está ativo ou inativo.

# if restaurante_praca.ativo:
#     print('O restaurante está ativo.')
# else:
#     print('O restaurante está inativo.')

# # 4 - Acesse o valor do atributo de classe categoria diretamente da classe Restaurante.

# categoria = Restaurante.categoria

# # 5 - Altere o valor do atributo nome para 'Bistrô'.

# restaurante_praca.nome = 'Bistrô'

# # 6 - Crie uma nova instância da classe Restaurante chamada restaurante_pizza com o nome 'Pizza Place' e categoria 'Fast Food'.

# restaurante_pizza = Restaurantes()

# restaurante_pizza.nome = 'Pizza Place'
# restaurante_pizza.categoria = 'Fast Food'

# # 7 - Verifique se a categoria da instância restaurante_pizza é 'Fast Food'.

# if restaurante_pizza.categoria == 'Fast Food':
#     print('A categoria é Fast Food.')
# else:
#     print('A categoria não é Fast Food.')

# # 8 - Mude o estado da instância restaurante_pizza para ativo.

# restaurante_pizza.ativo = True

# # 9 - Imprima no console o nome e a categoria da instância restaurante_praca.

# print(f'Nome: {restaurante_praca.nome}, Categoria: {restaurante_praca.categoria}')


# # Implemente uma classe chamada Carro com os atributos básicos, como modelo, cor e ano. Crie uma instância dessa classe e atribua valores aos seus atributos.

# class Carro:
#     def __init__(self, modelo ='', cor = '', ano = 0 ):
#         self.modelo = modelo
#         self.cor = cor
#         self.ano = ano

# carro1 = Carro('Vectra', 'Azul Calcinha', 1994)
# carro2 = Carro('Accord', 'Vermelho', 2002)
# carro3 = Carro('J4', 'Branco', 2011)

# # Crie uma classe chamada Restaurante com os atributos nome, categoria, ativo e crie mais 2 atributos. Instancie um restaurante e atribua valores aos seus atributos.

# class Restaurante:
#     def __init__(self, nome, categoria, bairro, cidade, ativo=False):
#         self.nome = nome
#         self.categoria = categoria
#         self.bairro = bairro
#         self.cidade = cidade
#         self.ativo = ativo

# restaurante_forner = Restaurante('Forner Hamburgueria', 'Hamburgueria', 'Vila Imaculada', 'Guarulhos', ativo=True)
# restaurante_marcos = Restaurante('Marcos Tratoria', 'Italiana', 'Jd. City', 'Guarulhos')

# # Adicione um método especial __str__ à classe Restaurante para que, ao imprimir uma instância, seja exibida uma mensagem formatada com o nome e a categoria. Exiba essa mensagem para uma instância de restaurante.


# class Restaurante:
#     def __init__(self, nome, categoria, cidade, bairro, ativo=False):
#         self.nome = nome
#         self.categoria = categoria
#         self.cidade = cidade
#         self.ativo = ativo
#         self.bairro = bairro
    
#     def __str__(self):
#         return f'{self.nome} | {self.categoria}| {self.bairro} | {self.cidade}'
    
# restaurante_forner = Restaurante('Forner Hamburgueria', 'Hamburgueria', 'Guarulhos', 'Jd. Célia')

# print(restaurante_forner)


# Crie uma classe chamada Cliente e pense em 4 atributos. Em seguida, instancie 3 objetos desta classe e atribua valores aos seus atributos através de um método construtor.

class Cliente:
    def __init__(self, nome = '', idade = 0, endereco = '', cpf = ''):
        self.nome = nome
        self.idade = idade
        self.endereco = endereco
        self.cpf = cpf
    
    def __str__(self):
        return f'{self.nome} | {self.idade} | {self.endereco} | {self.cpf}'
    
cliente_novo = Cliente('Vitoria', 26, 'Rua Bernardo Rodrigues Fernandes, 28', '45645645611')
cliente_novo2 = Cliente('Mateus', 25, 'Rua Sitio Novo de Goiás, 111', '15236552111')
cliente_novo3 = Cliente('Marcos', 33, 'Rua Abacate, 15', '1655552148')

print(cliente_novo)