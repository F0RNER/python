import os #importando bibliotecas

#restaurantes = ['Pizza', 'Sushi']#Cria uma lista global
restaurantes = [{'nome':'Praça', 'categoria':'Japonesa', 'ativo':False},#Isto é um dicionario
                {'nome':'Pizza Suprema', 'categoria':'Italiana', 'ativo':True},
                {'nome':'Forner Hamburgueria', 'categoria':'Haburguer', 'ativo':True}]

def exibir_nome_do_programa():
    '''Essa função é responsável por exibir o nome do programa''' 
    print("""
░██████╗░█████╗░██████╗░░█████╗░██████╗░  ███████╗██╗░░██╗██████╗░██████╗░███████╗░██████╗░██████╗
██╔════╝██╔══██╗██╔══██╗██╔══██╗██╔══██╗  ██╔════╝╚██╗██╔╝██╔══██╗██╔══██╗██╔════╝██╔════╝██╔════╝
╚█████╗░███████║██████╦╝██║░░██║██████╔╝  █████╗░░░╚███╔╝░██████╔╝██████╔╝█████╗░░╚█████╗░╚█████╗░
░╚═══██╗██╔══██║██╔══██╗██║░░██║██╔══██╗  ██╔══╝░░░██╔██╗░██╔═══╝░██╔══██╗██╔══╝░░░╚═══██╗░╚═══██╗
██████╔╝██║░░██║██████╦╝╚█████╔╝██║░░██║  ███████╗██╔╝╚██╗██║░░░░░██║░░██║███████╗██████╔╝██████╔╝
╚═════╝░╚═╝░░╚═╝╚═════╝░░╚════╝░╚═╝░░╚═╝  ╚══════╝╚═╝░░╚═╝╚═╝░░░░░╚═╝░░╚═╝╚══════╝╚═════╝░╚═════╝░
""")#Podemos usar a aspas triplas e ele usará a linha para quebra, sem usar o \n. A letra diferente é pega de um site fsymbols.

def exibir_opcoes():
    '''Função responsável por exibir as opções disponíveis para o usuário'''
    print('1. Cadastrar Restaurante')#Comando para mostrar.
    print('2. Listar Restaurante')
    print('3. Alternar Estado do Restaurante')
    print('4. Sair\n')

def finalizar_app():#def é para definir uma função.
    '''Função responsável por finalizar o app'''
    exibir_subtitulo('Finalizando o app\n')

def voltar_ao_menu_principal():
    '''Função responsável por voltar ao menu principal quando finalizamos alguma função do app
        Inputs:
        - Digitar qualquer tecla para voltar ao menu principal

    '''
    input('\nDigite uma tecla para voltar para o menu principal ')
    main()

def exibir_subtitulo(texto):
    '''Função responsável por exibir o subtitulo e pular linhas com o *'''
    os.system('cls')
    linha = '*' * (len(texto) + 4)#len é tamanho. Nesse caso, ele contará quantas letras terão somará mais 4 e multiplica por 4
    print(linha)
    print(texto)
    print(linha)
    print()

def opcao_invalida():
    ''' Responsável por avisar ao usuário se uma opção for inválida'''
    print('Opção Inválida')
    voltar_ao_menu_principal()

def validar_nome_restaurante(nome_do_restaurante):
  '''
  Valida se o nome do restaurante é válido.

  Argumentos:
    nome (str): O nome do restaurante a ser validado.

  Retorna:
    bool: True se o nome for válido, False caso contrário.
  '''
  nome_stripado = nome_do_restaurante.strip()  # Remove espaços em branco no início e no final
  if not nome_stripado:  # Verifica se o nome está vazio após remover espaços
    return False
  elif nome_stripado.isspace():  # Verifica se o nome contém apenas espaços
    return False
  else:
    return True

def cadastrar_novo_restaurante():
    ''' Essa função é responsável por cadastrar um novo restaurante
        Inputs:
        - O nome do restaurante
        - A categoria do restaurante
        Outputs:
        - Adiciona um restaurante a lista de restaurantes
    

    '''#Isso é uma docstring
    exibir_subtitulo('Cadastro de novos restaurantes:')
    nome_do_restaurante = input('Digite o nome do restaurante que deseja cadastrar: ')
    if validar_nome_restaurante(nome_do_restaurante) == False:
        opcao_invalida()
    else:
        categoria = input(f'Digite a categoria do restaurante {nome_do_restaurante}: ')
        dados_do_restaurante = {'nome':nome_do_restaurante, 'categoria':categoria, 'ativo':False}
        restaurantes.append (dados_do_restaurante)
    #restaurantes.append(nome_do_restaurante) #Adiciona o item na lista
        print(f'O restaurante {nome_do_restaurante} foi cadastrado com sucesso!')
        voltar_ao_menu_principal()


def listar_restaurantes():
    '''Função responsável por listar todos os restaurantes'''
    exibir_subtitulo('Lista de Restaurantes:\n')

    print(f'{'Nome do Restaurante'.ljust(22)} | {'Categoria'.ljust(20)} | {'Status'.ljust(20)}')
    for restaurante in restaurantes:
        nome_restaurante = restaurante['nome']
        categoria = restaurante['categoria']
        restaurante_ativo = restaurante['ativo']
        print(f'- {nome_restaurante.ljust(20)} | {categoria.ljust(20)} | ✔' if restaurante_ativo == True else f'- {nome_restaurante.ljust(20)} | {categoria.ljust(20)} | ❌')
    voltar_ao_menu_principal()

def alternar_estado_do_restaurante():
    '''Função responsável por Alternar o status dos restaurantes'''
    exibir_subtitulo('Alterando estado do restaurante')
    nome_restaurante = input('Digite o nome do restaurante que deseja alterar o estado: ')
    restaurante_encontrado = False

    
    for restaurante in restaurantes:
        if nome_restaurante == restaurante['nome']:
            restaurante_encontrado = True
            restaurante['ativo'] = not restaurante['ativo']
            mensagem = print(f'\nO restaurante {nome_restaurante} foi ativado com sucesso' if restaurante ['ativo'] else f'O restaurante {nome_restaurante} foi desativado com sucesso')
    if not restaurante_encontrado:
        print('\nO restaurante não foi encontrado.')
    voltar_ao_menu_principal()


def escolher_opcao():
    ''' Função responsável por ir para a tela de cada uma das opções caso escilhida'''
    try:
        opcao_escolhida = int (input('Escolha uma opção: '))#Esse comando é para inserir um comando do usuário no nosso código. Também transformamos ele em inteiro.
        #opcao_escolhida = int (opcao_escolhida) Uma forma de transformar a variável em int
        #print(type(opcao_escolhida))
        #print(type(1))
        if opcao_escolhida == 1: 
            cadastrar_novo_restaurante()
        elif opcao_escolhida == 2: #elif é o else if
            listar_restaurantes()
        elif opcao_escolhida == 3:
            alternar_estado_do_restaurante()
        elif opcao_escolhida == 4:
            finalizar_app
        else:
            opcao_invalida()
    except:
        opcao_invalida()

def main():
    ''' Função responsável por ir para tela principal'''
    os.system('cls')
    exibir_nome_do_programa()
    exibir_opcoes()
    escolher_opcao()


if __name__ == '__main__':
    main()